// src/sonos.ts

import { SonosHandler } from './sonos/index';
const sonos = new SonosHandler();
export default sonos;
