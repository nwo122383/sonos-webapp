// server/setupSettings.ts

import { DeskThing } from './initializer';
import sonos from './sonos';
import { AppSettings, SETTING_TYPES } from '@deskthing/types';

/**
 * Define and register all required settings for the Sonos app,
 * and assign the IP address to the active Sonos handler.
 */
export const setupSettings = async () => {
  const settings: AppSettings = {
    sonos_ip: {
      id: 'sonos_ip',
      label: 'Sonos IP Address',
      description: 'The IP address of your Sonos speaker or group coordinator.',
      type: SETTING_TYPES.STRING,
      value: '192.168.4.109', // Default fallback
    },
  };

  DeskThing.initSettings(settings);
  DeskThing.sendLog('[Sonos] Settings registered with DeskThing.');

  const savedSettings = await DeskThing.getSettings();
  DeskThing.sendLog(`Settings received: ${JSON.stringify(savedSettings)}`);

  const ip = savedSettings?.sonos_ip?.value;
  if (ip) {
    sonos.deviceIP = ip;
    DeskThing.sendLog(`[Sonos] IP set on handler: ${ip}`);
  } else {
    DeskThing.sendWarning('[Sonos] No IP found in settings.');
  }
};
