# sonos-webapp
 webapp for deskthing for sonos 
 So this is going to be an app specifically for the spotify carthing, which is now the deskthing. 
 This uses the IP address of the speaker, so make sure you have that ready. 
 This will display your favorites on the screen and allow you to play them, i have tested SiriusXM stations and Tunein with success. 
 Also, if you have songs favorited with youtube music they will play, at this time, playlists, albums, and stations with youtube music do not work, i dont use a lot of other streaming media so havent tested others. 
 this also shows the now playing album art and track info on the screen and you can control the volume. 
 If anyone wants to use it will be an alpha/early beta i guess.
