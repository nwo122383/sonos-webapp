export const config = {
  id: 'sonos-webapp',
  name: 'Sonos Controller',
  description: 'Control Sonos speakers from DeskThing',
  version: '0.11.0',
  permissions: [],
};
