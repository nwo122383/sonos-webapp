import React from 'react';

const NowPlaying: React.FC = () => {
  return null;
};

export default NowPlaying;
